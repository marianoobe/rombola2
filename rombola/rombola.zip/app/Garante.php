<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Garante extends Model
{
    //
}
