<?php $__env->startSection('content'); ?>
<body>      
    <!--<div class="mytop-content" >
        
        <div class="container" > 
          
                <div class="col-sm-12 " style="background-color:rgba(0, 0, 0, 0.35); height: 60px; " >
                   <a class="mybtn-social pull-right" href="<?php echo e(url('/register')); ?>">
                       Register
                  </a>

                  <a class="mybtn-social pull-right" href="<?php echo e(url('/login')); ?>">
                       Login
                  </a>
               
                </div>-->

 <div class="col-sm-12">
            <?php if(count($errors) > 0): ?>
            <div class="alert alert-danger">
                <strong>Whoops!</strong> <?php echo e(trans('adminlte_lang::message.someproblems')); ?><br><br>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
 </div>
            <div class="row">
              <div class="col-sm-6 col-sm-offset-3 myform-cont" >
                    <div class="myform-top">
                        <div align="center" class="myform-top-top">
                         <img src="<?php echo e(url('img/logogrande.png')); ?>" width="280" height="160" />
                        </div>
                                                
                    </div>
                    <div class="myform-bottom">
                    <form role="form" action="<?php echo e(url('/login')); ?>" method="post" class="">
                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                        <div class="form-group">
                            <input type="text"  name="<?php echo e(config('auth.providers.users.field','email')); ?>"
                        value="<?php echo e(old('')); ?>" placeholder="Correo Electrónico" class="form-control" id="form-username">
                        </div>
                        <div class="form-group">
                            <input type="password" name="password" placeholder="Contraseña" class="form-control" id="form-password">
                        </div>
                        <button type="submit" class="mybtn">Entrar</button>
                      </form>
                       <!--<a href="<?php echo e(url('/password/reset')); ?>"><?php echo e(trans('adminlte_lang::message.forgotpassword')); ?></a><br>   -->                    
                    </div>
              </div>
            </div>
            <div class="row">
                <div class="col-sm-12 mysocial-login">
                    
                    
                </div>
            </div>
        </div>
      </div>

    <!-- Enlazamos el js de Bootstrap, y otros plugins que usemos siempre al final antes de cerrar el body -->
    <script src="<?php echo e(url('js/bootstrap.min.js')); ?>"></script>
  </body>

<?php $__env->stopSection(); ?>






      

<?php echo $__env->make('adminlte::layouts.auth', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>