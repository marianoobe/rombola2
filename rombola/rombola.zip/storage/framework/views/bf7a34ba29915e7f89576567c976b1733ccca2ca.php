<<?php $__env->startSection('seccion'); ?>

<?php if (\Shinobi::can('prueba')): ?>
    <button>Crear</button>
<?php endif; ?>

<?php if (\Shinobi::can('jgjgj')): ?>
    <button>Venta</button>
<?php endif; ?>

<p>Contenido</p>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>