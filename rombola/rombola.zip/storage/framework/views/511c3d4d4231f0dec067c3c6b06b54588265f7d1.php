<?php $__env->startSection('seccion1'); ?>
<div class="container-fluid spark-screen">
	<div class="row">
		<div class="col-md-14 col-md-offset-0">
			<!-- Default box -->
			<div class="box box-primary">
				<div class="box-header with-border">
					<h3 class="box-title">PreVentas</h3>
				</div>
				<div class="box-body">


					<div class="col-sm-4 pull-left">
						 <a style="margin-bottom:10%;" role="button" href="<?php echo e(route('pre-venta.create')); ?>" class="btn btn-xl btn-success">NUEVA PREVENTA</a>
					</div>
					<div class="col-sm-4 pull-right">
						<form method="GET" action="<?php echo e(route('pre-venta.index')); ?>" class="navbar-form pull-right" role="search">
							<div class="input-group">
								<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
								<input type="text" class="form-control" name="name" placeholder="Busqueda">
								<input type="hidden" id="dato" name="dato" value="nuevo">
								<span class="input-group-btn">
									<button type="submit" class="btn btn-default">
										<span class="glyphicon glyphicon-search"></span>
									</button>
								</span>
							</div>
						</form>

					</div>
				</div>


				<table class="table table-striped">
					<thead>
						<tr>
							<th scope="col">Fecha</th>
							<th scope="col">Auto Buscado</th>
							<th scope="col">Auto Ofrecido</th>
							<th scope="col">Dinero que dispone</th>
							<th scope="col">Formas de Pago</th>
							<th scope="col">Estado</th>
							<th scope="col"></th>
						</tr>
					</thead>
					<tbody id="myTable">
						<?php $__currentLoopData = $preventa_cliente; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td><?php echo e($item->fecha_oper); ?></td>
							<td><?php echo e($item->auto_interesado); ?></td>
							<td><?php echo e($item->usado); ?></td>
							<td>$<?php echo e($item->contado); ?></td>
							<td><?php echo e($item->importe_finan); ?></td>
							<td><?php echo e($item->estado); ?></td>
							<td style="cursor: default;">
									<?php if (\Shinobi::can('vendedor')): ?>
								<a href="<?php echo e(route('pre-venta.edit',$item->dni)); ?>" class="btn btn-primary btn-sm">
									<span class="glyphicon glyphicon-search"></span></a>
									<?php endif; ?>
									<?php if (\Shinobi::can('admin')): ?>
									<a href="<?php echo e(route('pre-venta.edit',$item->dni)); ?>" class="btn btn-primary btn-sm">
								<span class="glyphicon glyphicon-search"></span></a>
								<a href="<?php echo e(route('print',$item->dni)); ?>" class="btn btn-primary btn-sm">
									<span class="glyphicon glyphicon-print"></span></a>														
										<a href="<?php echo e(route('pre-venta.destroy',$item->dni)); ?>" class="btn btn-danger btn-sm">
												<span class="glyphicon glyphicon-trash"></span></a>
									<?php endif; ?>
							</td>

						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</tbody>
				</table>
				<?php echo e($preventa_cliente->render()); ?>


				<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>