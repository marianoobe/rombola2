<div class="box-body">
        <div class="row margenBoot-25">
                <div class="col-xs-14 col-lg-6">
                        <input type="number" id="buscar_cliente" name="buscar_cliente" placeholder="Ingrese Auto"
                        class="form-control">
                </div>
                <div class="col-xs-14 col-lg-6">
                        <input type="number" id="buscar_cliente" name="buscar_cliente" placeholder="Ingrese Auto"
                        class="form-control"></div>
                </div>
        </div>
</div>