<?php $__env->startSection('content'); ?>

 <body>      
    <div class="mytop-content" >
        <div class="container" > 
                 <div class="col-sm-12 " style="background-color:rgba(0, 0, 0, 0.35); height: 60px; " >
                   <a class="mybtn-social pull-right" href="<?php echo e(url('/register')); ?>">
                       Register
                  </a>

                  <a class="mybtn-social pull-right"href="<?php echo e(url('/login')); ?>">
                       Login
                  </a>
               
                </div>
            <div class="row">

     
              <div class="col-sm-6 col-sm-offset-3 myform-cont" >
                    <div class="myform-top">
                        <div class="myform-top-left">
                          <img  src="<?php echo e(url('img/logo.png')); ?>" class="img-responsive logo" />
                          <h3>Regístrate en el sistema.</h3>
                            <p>Por favor ingresa tus datos:</p>
                        </div>
                        <div class="myform-top-right">
                          <i class="fa fa-user"></i>
                        </div>
                    </div>
            
          <div class="col-sm-12">
            <?php if(count($errors) > 0): ?>
            <div class="alert alert-danger">
                <strong>Whoops!</strong> <?php echo e(trans('adminlte_lang::message.someproblems')); ?><br><br>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>
           </div>

                    <div class="myform-bottom">
                      
                      <form role="form" action="" method="post" class="">
                       <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                    <div class="form-group">
                            <input type="text" name="name" value="<?php echo e(old ('name')); ?>" placeholder="Nombres..." class="form-control" id="form-firtsname">
                        </div>
                     
                        <div class="form-group">
                        <input type="text" name="email" value="<?php echo e(old ('email')); ?>" placeholder="Email..." class="form-control" id="form-email">
                            
                        </div>



                        <div class="form-group">
                            <input type="password" name="password" placeholder="Password..." class="form-control" id="form-password">
                        </div>


                         <div class="form-group">
                            <input type="password" name="password_confirmation" placeholder="Password..." class="form-control" id="form-password">
                        </div>
                            <div class="row">
                

                        <button type="submit" class="mybtn">Registrarme</button>
                      </form>
                      <a href="<?php echo e(url('/login')); ?>" class="text-center"><?php echo e(trans('adminlte_lang::message.membreship')); ?></a>
                    </div>
              </div>
            </div>
            <div class="row">
             <div class="col-sm-12 mysocial-login">
                    
                    
                </div>
            </div>
        </div>
      </div>

    <!-- Enlazamos el js de Bootstrap, y otros plugins que usemos siempre al final antes de cerrar el body -->
    <script src="<?php echo e(url('js/bootstrap.min.js')); ?>"></script>

   
  </body>

<?php $__env->stopSection(); ?>




<?php echo $__env->make('adminlte::layouts.auth', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>