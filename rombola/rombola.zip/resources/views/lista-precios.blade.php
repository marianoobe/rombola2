@extends('adminlte::layouts.app')

@section('seccion')

<div class="container-fluid spark-screen">
        <div class="row">
            <div class="col-md-14 col-md-offset-0">
                <!-- Default box -->
                <div class="box box-primary">
                    <div class="box-body">
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
    
@endsection