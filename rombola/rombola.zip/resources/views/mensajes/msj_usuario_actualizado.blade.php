
<div class="box box-primary col-xs-12">


<div class='aprobado' style="margin-top:70px; text-align: center">
  <span class="label label-success">Usuario Actualizado<i class="fa fa-check"></i></span><br/>
<label style='color:#177F6B'>
              <?php  echo $msj; ?> 
</label> 

</div>




 

 </div> 

