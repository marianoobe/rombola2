<?php

return [
    'run-migrations' => true,
];
